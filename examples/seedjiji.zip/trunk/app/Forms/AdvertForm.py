from formimports import *

def AdvertForm(user, ad=None):

  form_config = { #field_name : (reqyured, widget, label),
                  'ad_type' : [True, widgets.Select, 'Ad Type'],
                  'species' : [True, widgets.TextInput, 'Species'],
                  'cultivar' : [True, widgets.TextInput, 'Cultivar'],
                  'price' : [False, widgets.TextInput, 'Price'],
                  'quantity_scalar' : [True, widgets.TextInput, 'Quantity'],
                  'quantity_unit' : [True, widgets.Select, ''],
                  'comments' : [True, NoteInput, 'Comments'],
                }
  widget_for_field = {}
  class Advertform(forms.Form):
    ad_type = SecureChoiceField( required = form_config['ad_type'][0],
                                 widget = form_config['ad_type'][1],
                                 label = form_config['ad_type'][2],
                                 choices = Configuration.ad_types,
                                 initial = ad and ad.ad_type or Configuration.ad_types[0][0],
                                )
    species = SecureCharField( required=form_config['species'][0],
                               widget = form_config['species'][1],
                               label = form_config['species'][2],
                               initial = ad and ad.species or '',
                              )
    cultivar = SecureCharField( required = form_config['cultivar'][0],
                                widget = form_config['cultivar'][1],
                                label = form_config['cultivar'][2],
                                initial = ad and ad.cultivar or '',
                               )
    price = SecureDecimalField( required = form_config['price'][0],
                                widget = form_config['price'][1],
                                label = form_config['price'][2],
                                decimal_places = 2,
                                max_digits = 10,
                                initial = ad and ad.price or 0,
                               )
    quantity_scalar = SecureCharField( required = form_config['quantity_scalar'][0],
                                       widget = form_config['quantity_scalar'][1],
                                       label = form_config['quantity_scalar'][2],
                                       initial = ad and ad.quantity_scalar or '',
                                      )
    quantity_unit = SecureChoiceField( required = form_config['quantity_unit'][0],
                                       widget = form_config['quantity_unit'][1],
                                       label = form_config['quantity_unit'][2],
                                       choices = Configuration.quantity_units,
                                       initial = ad and ad.quantity_unit or Configuration.quantity_units[0][0],
                                      )
    comments = SecureCharField( required = form_config['comments'][0],
                                widget = form_config['comments'][1],
                                label = form_config['comments'][2],
                                initial = ad and ad.comments or ''
                               )

  return Advertform
