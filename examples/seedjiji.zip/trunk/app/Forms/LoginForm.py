from formimports import *

def LoginForm(request):
  class Loginform(forms.Form):
        username = forms.fields.CharField(label=t('en', "Username"), required=True)
        password = forms.fields.CharField(label=t('en', "Password"), widget=forms.widgets.PasswordInput, initial="", required=True)
  return Loginform

