from formimports import *
from DataObjects.models import UserProfile, User

def UserForm(user, mode='edit'):
  form_config = {}
  if mode == 'new':
    form_config = { # field_name : (required, widget, visible),
                    'username' : (True, widgets.TextInput, True),
                    'email' : (True, widgets.TextInput, True),
                    'fname' : (True, widgets.TextInput, True),
                    'lname' : (True, widgets.TextInput, True),
                    'phone1' : (True, widgets.TextInput, True),
                    'phone2' : (False, widgets.TextInput, True),
                    'street1' : (False, widgets.TextInput, True),
                    'street2' : (False, widgets.TextInput, True),
                    'city' : (False, widgets.TextInput, True),
                    'province' : (True, widgets.Select, True),
                    'country' : (True, widgets.Select, True),
                    'post_code' : (True, widgets.TextInput, True),
                    'about' : (False, NoteInput, True),
                    'image' : (False, widgets.FileInput, True),
                    'mailingList' : (False, widgets.CheckboxInput, True),
                    'password1' : (True, widgets.PasswordInput, True),
                    'password2' : (True, widgets.PasswordInput, True),
                   }

  elif mode == 'edit':
    form_config = { # field_name : (required, widget, visible),
                    'username' : (True, widgets.TextInput, True),
                    'email' : (False, ROSpan, True),
                    'fname' : (True, widgets.TextInput, True),
                    'lname' : (True, widgets.TextInput, True),
                    'phone1' : (True, widgets.TextInput, True),
                    'phone2' : (False, widgets.TextInput, True),
                    'street1' : (False, widgets.TextInput, True),
                    'street2' : (False, widgets.TextInput, True),
                    'city' : (False, widgets.TextInput, True),
                    'province' : (True, widgets.Select, True),
                    'country' : (True, widgets.Select, True),
                    'post_code' : (True, widgets.TextInput, True),
                    'about' : (False, NoteInput, True),
                    'image' : (False, ImageFileInput, True),
                    'mailingList' : (False, widgets.CheckboxInput, True),
                    'password1' : (False, widgets.PasswordInput, False),
                    'password2' : (False, widgets.PasswordInput, False),
                   }
  elif mode == 'other':
    form_config = { # field_name : (required, widget, visible),
                    'username' : (False, ROSpan, True),
                    'email' : (False, ROSpan, False),
                    'fname' : (False, ROSpan, False),
                    'lname' : (False, ROSpan, False),
                    'phone1' : (False, ROSpan, False),
                    'phone2' : (False, ROSpan, False),
                    'street1' : (False, ROSpan, False),
                    'street2' : (False, ROSpan, False),
                    'city' : (False, ROSpan, True),
                    'province' : (False, ROSpan, True),
                    'country' : (False, ROSpan, True),
                    'post_code' : (False, ROSpan, False),
                    'about' : (False, ROSpan, True),
                    'image' : (False, ImagePreview, True),
                    'mailingList' : (False, ROSpan, False),
                    'password1' : (False, ROSpan, False),
                    'password2' : (False, ROSpan, False),
                   }
  elif mode == 'buddy':
    form_config = { # field_name : (required, widget, visible),
                    'username' : (False, ROSpan, True),
                    'email' : (False, ROSpan, True),
                    'fname' : (False, ROSpan, False),
                    'lname' : (False, ROSpan, False),
                    'phone1' : (False, ROSpan, True),
                    'phone2' : (False, ROSpan, True),
                    'street1' : (False, ROSpan, True),
                    'street2' : (False, ROSpan, True),
                    'city' : (False, ROSpan, True),
                    'province' : (False, ROSpan, True),
                    'country' : (False, ROSpan, True),
                    'post_code' : (False, ROSpan, True),
                    'about' : (False, ROSpan, True),
                    'image' : (False, ImagePreview, True),
                    'mailingList' : (False, ROSpan, False),
                    'password1' : (False, ROSpan, False),
                    'password2' : (False, ROSpan, False),
                   }
  elif mode == 'admin':
    form_config = { # field_name : (required, widget, visible),
                    'username' : (True, widgets.TextInput, True),
                    'email' : (True, widgets.TextInput, True),
                    'fname' : (True, widgets.TextInput, True),
                    'lname' : (True, widgets.TextInput, True),
                    'phone1' : (True, widgets.TextInput, True),
                    'phone2' : (False, widgets.TextInput, True),
                    'street1' : (False, widgets.TextInput, True),
                    'street2' : (False, widgets.TextInput, True),
                    'city' : (False, widgets.TextInput, True),
                    'province' : (True, widgets.Select, True),
                    'country' : (True, widgets.Select, True),
                    'post_code' : (True, widgets.TextInput, True),
                    'about' : (False, NoteInput, True),
                    'image' : (False, ImageFileInput, True),
                    'mailingList' : (False, widgets.CheckboxInput, True),
                    'password1' : (True, widgets.PasswordInput, True),
                    'password2' : (True, widgets.PasswordInput, True),
                   }
  else:
    pass

  label_for_field = dict([ (k, t('en', v)) for k, v in {
                           'username' : 'Username',
                           'email' : 'Email Address',
                           'fname' : 'First Name',
                           'lname' : 'Last Name',
                           'phone1' : 'Primary Phone Number',
                           'phone2' : 'Secondary Phone Number',
                           'street1' : 'Street Address',
                           'street2' : '',
                           'city' : 'City',
                           'province' : 'State/Province',
                           'country' : 'Country',
                           'post_code' : 'Postal Code',
                           'about' : 'About',
                           'image' : 'Your Avatar',
                           'mailingList' : 'Would you like to receive Newsletters?',
                           'password1' : 'Password',
                           'password2' : 'Confirm Password',
                         }.items()])
  required_field = dict([ (k, v[0]) for k, v in form_config.items() ])
  widget_for_field = dict([ (k, v[1]) for k, v in form_config.items() ])
  visibility = dict([ (k, v[2]) for k, v in form_config.items() ])
  formFields = [ k for k in form_config.keys() ]

  class Userform(forms.ModelForm):
    class Meta:
      model = UserProfile
      fields = formFields

    username = SecureCharField(required = required_field['username'],
                               widget = widget_for_field['username'],
                               label = label_for_field['username'],
                               initial = user and user.user.username or '',
                             )
    email = SecureCharField(required = required_field['email'],
                            widget = widget_for_field['email'],
                            label = label_for_field['email'],
                            initial = user and user.user.email or '',
                          )
    fname = SecureCharField(required = required_field['fname'],
                            widget = widget_for_field['fname'],
                            label = label_for_field['fname'],
                            initial = user and user.fname or '',
                          )
    lname = SecureCharField(required = required_field['lname'],
                            widget = widget_for_field['lname'],
                            label = label_for_field['lname'],
                            initial = user and user.lname or '',
                            )
    phone1 = SecureCharField(required = required_field['phone1'],
                             widget = widget_for_field['phone1'],
                             label = label_for_field['phone1'],
                             initial = user and user.phone1 or '',
                             )
    phone2 = SecureCharField(required = required_field['phone2'],
                             widget = widget_for_field['phone2'],
                             label = label_for_field['phone2'],
                             initial = user and user.phone2 or '',
                             )
    street1 = SecureCharField(required = required_field['street1'],
                             widget = widget_for_field['street1'],
                             label = label_for_field['street1'],
                             initial = user and user.street1 or '',
                             )
    street2 = SecureCharField(required = required_field['street2'],
                             widget = widget_for_field['street2'],
                             label = label_for_field['street2'],
                             initial = user and user.street2 or '',
                             )
    city = SecureCharField(required = required_field['city'],
                          widget = widget_for_field['city'],
                          label = label_for_field['city'],
                          initial = user and user.city or '',
                          )
    province = SecureChoiceField(required = required_field['province'],
                                widget = widget_for_field['province'],
                                label = label_for_field['province'],
                                choices = Configuration.provinces,
                                initial = user and user.province or Configuration.provinces[0][0],
                                )
    country = SecureChoiceField(required = required_field['country'],
                                widget = widget_for_field['country'],
                                label = label_for_field['country'],
                                choices = Configuration.countries,
                                initial = user and user.country or Configuration.countries[0][0],
                                )
    post_code = SecureCharField(required = required_field['post_code'],
                                widget = widget_for_field['post_code'],
                                label = label_for_field['post_code'],
                                initial = user and user.post_code or '',
                                )
    about = SecureCharField(required = required_field['about'],
                            widget = widget_for_field['about'],
                            label = label_for_field['about'],
                            initial = user and user.about or '',
                            )
    image = SecureImageField(required = required_field['image'],
                            widget = widget_for_field['image'],
                            label = label_for_field['image'],
                            initial = user and user.image or '',
                            )
    mailingList = SecureBooleanField(required = required_field['mailingList'],
                                     widget = widget_for_field['mailingList'],
                                     label = label_for_field['mailingList'],
                                     initial = user and user.mailingList or False,
                                     )
    password1 = SecureCharField(required = required_field['password1'],
                                widget = widget_for_field['password1'],
                                label = label_for_field['password1'],
                                initial = '',
                                )
    password2 = SecureCharField(required = required_field['password2'],
                                widget = widget_for_field['password2'],
                                label = label_for_field['password2'],
                                initial = '',
                                )

    def clean_phone1(self):
      tn = self.cleaned_data['phone1']
      tn = re.sub('(^1)|(\D*)', '', tn)
      return tn
    
    def clean_phone2(self):
      tn = self.cleaned_data['phone2']
      tn = re.sub('(^1)|(\D*)', '', tn)
      return tn
    
    def clean_password(self):
      existing = self.instance.id is not None
      p = self.cleaned_data['password1']
      if p == '':
        return p
      if existing:
        return Configuration.password_validator(p)
      return p

    def clean_username(self):
      u = self.cleaned_data['username']
      userreg = re.compile(r'^[a-zA-Z]')
      if not userreg.match(u):
        raise util.ValidationError('Username must start with a letter')
      if User.objects.filter(username=u).exclude(id=self.instance.user_id).count():
        raise util.ValidationError('That username is already in use (%s)' % self.instance.user_id)
      return u

    def clean_emailAddress(self):
      existing = self.instance.id is not None
      e = self.cleaned_data['email_address']
      if existing and User.objects.filter(email=e).exclude(id=self.instance.user_id).count():
         raise util.ValidationError('That email address is in use by another user')
      ##TODO: validate email address
      return e

    def clean(self):
      existing = self.instance.id is not None
      p1 = self.cleaned_data['password1']
      p2 = self.cleaned_data['password2']
      if p1 and p1 != p2:
        raise util.ValidationError('Passwords do not match')
      return self.cleaned_data
    
    def save(self, *argc, **argv):
      if self.instance.id is None:
        try:
          self.user = User.objects.create_user( username = self.cleaned_data['username'],
                                                email = self.cleaned_data['email'],
                                              )
        except:
          assert False, ("Tried to create user account", 
                          saferepr(self.cleaned_data['username']),
                          saferepr(self.cleaned_data['email']),
                        )
        self.user.save()
        self.user.set_password(self.cleaned_data['password1'])
        self.user.save()
        self.instance = UserProfile( user = self.user, 
                                     fname = self.cleaned_data['fname'],
                                     lname = self.cleaned_data['lname'],
                                     phone1 = self.cleaned_data['phone1'],
                                     phone2 = self.cleaned_data['phone2'],
                                     street1 = self.cleaned_data['street1'],
                                     street2 = self.cleaned_data['street2'],
                                     city = self.cleaned_data['city'],
                                     province = self.cleaned_data['province'],
                                     country = self.cleaned_data['country'],
                                     post_code = self.cleaned_data['post_code'],
                                     about = self.cleaned_data['about'],
                                     image = self.cleaned_data['image'],
                                     mailingList = self.cleaned_data['mailingList'],
                                     latitude=0,
                                     longitude=0
                                   )
        self.instance.save()
      else:
        self.instance.user.username = self.cleaned_data['username']
        if self.cleaned_data['password1']:
          self.instance.user.set_password(self.cleaned_data['password1'])
        self.instance.user.email = self.cleaned_data['email']
        self.instance.user.save()
        return super(Userform, self).save(*argc, **argv)
      ret = super(Userform, self).save(*argc, **argv)
      return ret
  return Userform
