from formimports import *

def FilterForm(user):
  ChoiceField = forms.ChoiceField
  DecimalField = forms.DecimalField
  user_province = user is not None and user.province or Configuration.provinces[0][0]
  class Filterform(forms.Form):
    ad_type = ChoiceField( required = False,
                           choices = (( 'BS' , 'Both'), ('B', 'Buying'), ('S', 'Selling' )),
                           label = 'Ad Type',
                           initial = 'S'
                        )
    quantity_scalar = DecimalField( required = False,
                                    label = 'Minimum Quantity',
                                    initial = 0
                                  )
    quantity_unit = ChoiceField( required = False,
                                choices = Configuration.quantity_units,
                                label = '',
                                initial = Configuration.quantity_units[0][0]
                              )
    province = ChoiceField( required = False,
                            choices = Configuration.provinces,
                            label = 'Province',
                            initial = user_province,
                          )
    distance = ChoiceField( required = False,
                            choices = Configuration.distances,
                            label = 'Max Distance',
                            initial = Configuration.distances[-1][0],
                          )
    status = ChoiceField( required = False,
                          choices = Configuration.ad_statii,
                          label = 'Status',
                          initial = Configuration.ad_statii[0][0],
                        )
  return Filterform

def SearchForm(user):
  CharField = forms.CharField

  class Searchform(forms.Form):

    date_from = DateField( required = False,
                           label = 'Date From',
                           initial = datetime.date.today(),
                           input_formats = ['%m-%d-%Y']
                         )
    date_to = DateField( required = False,
                         label = 'Date To',
                         initial = datetime.date.today() + datetime.timedelta(days=365),
                         input_formats = ['%m-%d-%Y']
                       )
    species = CharField( required = False,
                         label = 'Species',
                         initial = ''
                       )
    cultivar = CharField( required = False,
                          label = 'Cultivar',
                          initial = ''
                         )
  return Searchform
