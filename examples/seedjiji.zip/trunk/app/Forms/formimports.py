import django.forms as forms
from pprint import saferepr
from django.forms import ModelForm, fields, util, models, widgets
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from seedjiji.templatetags.t import t
from DataObjects.Configuration import Configuration
import re, datetime

class NoteInput(widgets.Textarea):
  def render(self, name, value, attrs=None):
    ta = super(NoteInput, self).render(name, value, attrs=attrs)
    return ta

class ROSpan(widgets.Widget):
    """
    This widget renders the field as a <span> instead of an input.
    This is useful when switching the widget type of a newforms class
    especially if the class is produced dynamically.
    """
    def __init__(self, attrs=None, choices=()):
        super(ROSpan, self).__init__(attrs)
        self.choices = list(choices)

    def render(self, name, value, attrs=None):
        if value is None: value = ''
        final_attrs = self.build_attrs(attrs, name=name)
        final_attrs.pop('name', None) #remove name since this is invalid xml
        if self.choices:
          choice_string = [ c[1] for c in self.choices if c[0] == value ]
          value = len(choice_string) and choice_string[0] or value
        return mark_safe(u'<span%s>%s</span>' % (util.flatatt(final_attrs), value))

class ImageFileInput(widgets.FileInput):
  pass

class ImagePreview(ROSpan):
  pass

class DateInput(widgets.TextInput):
  """This widget is a text field with date picker."""
  def __init__(self, attrs=None, choices=()):
    super(DateInput, self).__init__(attrs)
    self.choices = list(choices)

  def render(self, name, value, attrs=None):
    self.format = attrs.pop('date_format', '%m-%d-%Y')
    textinput = super(DateInput, self).render(name, value, attrs)
    id = attrs['id']
    if len(self.choices):
      return textinput
    return mark_safe("""%s<img src="/media/img/calendar.gif" height="16" width="16" onclick="scwShow(document.getElementById('%s'),event);" />
<script type="text/javascript">//<![CDATA[
//]]></script>""" % (textinput, id))

class DateField(forms.Field):
  widget = DateInput
  default_error_messages = {
    'invalid': _(u'Enter a valid date.'),
  }
  def __init__(self, input_formats=None, *args, **kwargs):
    self.input_formats = input_formats
    self.format = input_formats[0]
    super(DateField, self).__init__(*args, **kwargs)

  def clean(self, value):
    """
    Validates that the input can be converted to a date. Returns a Python
    datetime.date object.
    """
    super(DateField, self).clean(value)
    if value in (None, ''): return None
    if isinstance(value, datetime.datetime): return value.date()
    if isinstance(value, datetime.date): return value
    for format in self.input_formats:
      try:
        return datetime.date(*time.strptime(value, format)[:3])
      except ValueError:
        continue
    raise util.ValidationError(self.error_messages['invalid'])

  """
  def widget_attrs(self, widget):
    if isinstance(widget, DateInput):
      return {'date_format' : self.format}
    return {}
  """

class EmailField(forms.Field):
  widget = widgets.TextInput
  default_error_messages = {
    'invalid': _(u'Enter a valid email address.'),
  }

  def clean(self, value):
    """
    Validates that the input can be converted to a date. Returns a Python
    datetime.date object.
    """
    super(EmailField, self).clean(value)
    if value in (None, ''): return None
    value = value.strip()
    parts = value.split('@')
    if len(parts) != 2:
      raise util.ValidationError(self.error_messages['invalid'])

    localchar = r'[a-zA-Z0-9!#$%*/?\^{}`~&\'+=_-]'
    extlocalchar = r'[a-zA-Z0-9!#$%*/?\^{}`~&\'+=_.-]'
    local = re.compile(r'^(%s+%s?)*%s+$' % (localchar, extlocalchar, localchar))
    oneChar = re.compile(r'^%s$' % localchar)
    m = local.match(parts[0])
    n = oneChar.match(parts[0])
    if not m or n:
      raise util.ValidationError(self.error_messages['invalid'])
    dparts = parts[1].split('.')
    dchar = r'[a-zA-Z0-9]'
    dextchar = r'[a-zA-Z0-9-]'
    domain = re.compile(r'^(%s+%s?)*%s+$' % (dchar, dextchar, dchar))
    oneDChar = re.compile(r'^%s$' % dchar)
    if [ True for hn in dparts
         if not (domain.match(hn) or oneDChar.match(hn))
       ] or len(dparts) < 2:
      raise util.ValidationError(self.error_messages['invalid'])
    return value

class PhoneNumberField(forms.Field):
  widget = widgets.TextInput
  default_error_messages = {
    'invalid': _(u'Should resemble (xxx) yyy-zzzz ext aaaa'),
  }

  def clean(self, value):
    """
    Validates that the input can be converted to a 10+ digit raw phone number. 
    Returns a string.
    """
    super(PhoneNumberField, self).clean(value)
    if value in (None, ''): return None
    pnr = re.compile(r'^1?[( .:-]{0,3}(\d{3})[) .:-]{0,3}(\d{3})[ .:-]{0,3}(\d{4})( ?e?xt?.? ?([0-9]*))?$')
    m = pnr.match(value.strip())
    if m:
      return ''.join([ g for g in m.groups() if g is not None])
    raise util.ValidationError(self.error_messages['invalid'])

def SecureFieldFactory(BaseField):
  class SecureField(BaseField):
    def __init__(self, html_attrs=(), *argc, **argv):
      self.html_attrs = dict(html_attrs)
      if argv.get('required', False) and not argv.get('widget', None) == ROSpan:
        argv['label'] = mark_safe("%s %s" % (argv.get('label', ''), '<span class="errors">*</span>'))
      super(SecureField, self).__init__(*argc, **argv)
    def clean(self, value, initial=None):
      if self.widget.__class__ == ROSpan:
        self.widget.value_from_datadict = lambda a,b,c: self.initial
        return self.initial
      if isinstance(BaseField, fields.FileField):
        return super(SecureField, self).clean(value, initial=initial)
      return super(SecureField, self).clean(value)
    def widget_attrs(self, widget):
      return self.html_attrs
  return SecureField

SecureChoiceField = SecureFieldFactory(forms.ChoiceField)
SecureCharField = SecureFieldFactory(forms.CharField)
SecureIntField = SecureFieldFactory(forms.IntegerField)
SecureDecimalField = SecureFieldFactory(forms.DecimalField)
SecureBooleanField = SecureFieldFactory(forms.BooleanField)
SecureImageField = SecureFieldFactory(forms.ImageField)
SecureDateField = SecureFieldFactory(DateField)
SecureEmailField = SecureFieldFactory(EmailField)
SecurePhoneField = SecureFieldFactory(PhoneNumberField)
