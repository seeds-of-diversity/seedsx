from ViewImports import *

class HomePage(SiteServlet):
  title = 'Home'
  template = 'home_page.tmpl'
  def manage_request(self):
    pass
  def butWaitTheresMore(self, fields):
    fields['show_home_link'] = False
    return fields
