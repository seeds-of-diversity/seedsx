from ViewImports import *
from Forms import AdvertForm

class AdvertServlet(SiteServlet):
  template = "ad_new.tmpl"
  def manage_request(self):
    af = AdvertForm(user=self.profile, ad=None)
    if self.method == 'POST' and (self.POST.get('adform', '') == 'ADFORM') and self.validForm():
      self.fields['ad_form'] = af(self.POST)
    self.fields['ad_form'] = af()
