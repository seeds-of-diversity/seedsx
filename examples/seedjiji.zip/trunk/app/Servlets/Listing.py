from ViewImports import *
from Forms import FilterForm, SearchForm

class ListingCell(object):
  def __init__(self, text, klass=""):
    self.text = text
    self.klass = klass

def ListingRow(object):
  def __init__(self, items, klass):
    self.items = items
    self.klass = klass

class ListingField(object):
  columns = []
  def __init__(self, id, text, klass):
    self.id = id
    self.text = text
    self.klass = klass

class ListingTable(object):
  rows = []
  columns = []

  def addColumn(self, id, label=None, klass=""):
    assert len(rows.keys()) == 0, "Must define all headings before adding data"
    if label is None: label = id
    assert id not in [ c.id for c in self.columns ], "Duplicate Column id (%s)" % id
    self.columns.append(ListingField(id=id, klass=klass, text=label))

  def addRow(self, data=None, klass=""):
    if data is None: data = {}
    self.rows.append(ListingRow([ ListingCell(data.get(c.id, ""), klass)
                                  for c in self.columns ], klass ))

  def headings(self):
    return [ { 'klass' : c.klass,
               'text' : c.text,
               'id' : c.id,
             } for c in self.columns
           ]

  def items(self):
    return self.columns

class ListingServlet(SiteServlet):
  template = "ad_list.tmpl"
  def manage_request(self, *args, **kwargs):
    ff = FilterForm(self.profile)
    self.fields['filter_form'] = ff()
    sf = SearchForm(self.profile)
    self.fields['search_form'] = sf() 
    self.fields['data_table'] = ListingTable()
