from ViewImports import *

class FeedbackServlet(SiteServlet):
  pass
