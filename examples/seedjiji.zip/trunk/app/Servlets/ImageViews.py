from ViewImports import *

class ImageServlet(SiteServlet):
  pass
