from ViewImports import *

class AccountServlet(SiteServlet):
  template = 'account_page.tmpl'
  title = 'My Account'
  def manage_request(self):
    edited_user = None
    if self.mode == 'new':
      if not self.user.is_anonymous() and not self.profile.role == 'A':
        self.addMessage(messages.constants.ERROR, 'Only administrators may add additional user accounts')
        self.sendRedirect('/home')
        return super(AccountServlet, self).manage_request()

      self.template = 'account_new.tmpl'
      self.title = 'Create an Account'
    elif self.mode == 'edit':
      if self.pathArgs['user_id'] is None:
        edited_user = self.profile
      else:
        try:
          edited_user = UserProfile.objects.get(id=int(self.pathArgs['user_id']))
        except:
          self.addMessage(messages.constants.ERROR, 'Invalid user account.')
          self.sendRedirect('/')

    _uf = UserForm(self.profile, mode=self.mode)
    if self.method == 'POST' and (self.POST.get('userform', '') == 'USERFORM') and self.validForm():
      uf = _uf(self.POST, instance=edited_user)
      if uf.is_valid():
        uf.save()
        profile = uf.instance
        if self.mode == 'new':
          profile.verifCode = sha.sha(str(random.random())).hexdigest()[5:15]
          profile.verified = False
          profile.active = False
          profile.save()
          self.fields['new'] = profile
          Email.new_user(new=profile, manager=self.profile, activation_code=profile.verifCode)
          self.expireTokens()
          activation_path = '/activate/%d/%s' % (profile.user.id, profile.verifCode)
          self.addMessage(messages.constants.INFO, 'An account has been created.  A verification code has been emailed to %s with instructions on activating this account' % (profile.user.email))
          self.addMessage(messages.constants.DEBUG, 'DEBUG: %s' % (activation_path))
          if self.profile and self.profile.role == 'A':
            self.sendRedirect('/user/%d' % profile.id)
          self.sendRedirect('/')
        else:
          self.addMessage(messages.constants.INFO, 'User Account Saved')
          Email.user_saved(user=profile, manager=self.profile)
          self.sendRedirect('/user/%d' % profile.id)
    else:
      uf = _uf(instance=edited_user)
      #self.fields['captcha'] = self.mkCaptcha()
    self.fields['user_form'] = uf
