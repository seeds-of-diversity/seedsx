from ViewImports import *

class ErrorServlet(SiteServlet):
  def manage_request(self):
    if self.mode == '404': 
      self.title = 'Not Found'
