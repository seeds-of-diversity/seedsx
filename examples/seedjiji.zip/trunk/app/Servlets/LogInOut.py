from ViewImports import *

class AuthServlet(SiteServlet):
  pass

class Credentials(SiteServlet):
  template = 'reset/step1.tmpl'
  def manage_request(self):
    if self.mode == 'activate':
      try:
        user_id = int(self.pathArgs['user_id'])
        activation_code = self.pathArgs['activation_code']
        assert activation_code is not None, self.pathArgs
        profile = UserProfile.objects.get(id=user_id)
      except:
        self.addMessage(messages.constants.ERROR, 'Invalid Activation Code')
        self.sendRedirect('/')
      if profile.verified:
        self.addMessage(messages.constants.WARNING, 'This account has already been activated')
      if profile.verifCode == activation_code:
        profile.verified = True
        profile.activation_code = ''
        profile.active = True
        profile.save()
        self.addMessage(messages.constants.INFO, 'Your account has been activated.  You may now login.')
      else:
        self.addMessage(messages.constants.ERROR, 'Invalid Activation Code')
      self.sendRedirect('/')
    elif self.mode == 'reset':
      pass
    else:
      self.addMessage(messages.constants.ERROR, 'Invalid operation (%s)' % self.mode)
      self.sendRedirect('/')
