from os import environ, path
import sha, random, datetime, time, re
from django.db.models.base import ObjectDoesNotExist
from django.db import transaction
import django.forms as forms
from django.http import HttpResponse, HttpResponseRedirect
from django.utils.safestring import mark_safe
from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.auth import login, authenticate
from django.template import Context, loader
from django.core.mail import EmailMessage
from django.contrib import messages
from DataObjects.models import *
from seedjiji.security import *
from datetime import datetime, timedelta
from Forms import *
import seedjiji.Email as Email
from seedjiji.templatetags.t import t
import seedjiji.settings as settings

def createView(Servlet, args, mode=None):
  def handler(request, **kwargs):
    s = Servlet(request, mode=mode)
    if args is not None:
      s.parsePath(args, **kwargs)
    return s.respond()
  handler.csrf_exempt = True
  return handler

class ImplementationError(Exception):
  pass

class Redirect(Exception):
  def __init__(self, url):
    self.url = url

class Token(object):
  def expired(self):
    return timedelta(hours=1) < (datetime.now() - self.time)
  def __init__(self, servlet):
    self.time = datetime.now()
    self.v = sha.sha(str(random.random())).hexdigest()
  def __call__(self, auth=None):
    if auth: return unicode(auth) == unicode(self.v) and not self.expired()
    return not self.expired()

class SiteServlet(object):
  refreshFormID = True ##Set to False in subclass if you need to retain the last formid for some reason or other.
  is_async = False ##Set to True for JSONCommunicator Subclasses.
  user = property(lambda s: s.request.user)
  profile = property(lambda s: s._profile())
  session = property(lambda s: s.request.session)
  cookies = property(lambda s: s.request.COOKIES)
  POST = property(lambda s: s.request.POST)
  GET = property(lambda s: s.request.GET)
  FILES = property(lambda s: s.request.FILES)
  template = property(lambda s: s._template())
  title = ''

  def _profile(self):
    if self.__profile is not False: return self.__profile
    self.__profile = (not self.request.user.is_anonymous()) and self.request.user.get_profile() or None
    return self.__profile

  def _template(self):
    raise ImplementationError('template must be defined by subclass')

  def _title(self):
    if callable(self.title):
      return self.title()
    return self.title

  def __init__(self, request, mode=None):
    self.request = request
    self.mode = mode
    self.mayReturn = False
    self.returnPath = False
    self.fields = {}
    self.pathArgs = {}
    self.method = request.method
    self.__profile = False
    if self.request.META.has_key('HTTP_X_FORWARDED_HOST'):
      self.request.META['HTTP_HOST'] = self.request.META['HTTP_X_FORWARDED_HOST']
    if self.is_async:
      self.parseJSONCommunicator()
    else:
      if self.user.is_anonymous() and self.POST.get('loginform') == 'login' and self.validForm():
        self.fields['login'] = self.checkLogin(LoginForm('en')(self.POST))
      else:
        self.fields['login'] = LoginForm('en')()

  def checkLogin(self, lf):
    if lf.is_valid():
      user = authenticate(username=lf.cleaned_data['username'],
                          password=lf.cleaned_data['password'],
                         )
      if user is not None:
        if not (user.is_active and user.get_profile().active and user.get_profile().verified):
          self.addMessage(messages.constants.WARNING, 'User Account Disabled.  Please email the administrator.')
        else:
          login(self.request, user)
          self.addMessage(messages.constants.INFO, 'Thanks for logging in')
      else:
        self.addMessage(messages.constants.WARNING, 'Username/Password Error')
    return lf

  def parseJSONCommunicator(self):
    response = {'success' : False, 'error' : []}
    try:
      assert  'text/x-json' in [ unicode(t).strip()
                                for t in self.request.META['CONTENT_TYPE'].split(';')
                              ]
    except:
      response['error'].append('Bad content type')
    try:
      POST = json.loads(self.request.raw_post_data)
      command = unicode(POST['command'])
      response['attr'] = command
      assert type(POST['payload']) == dict, "payload is a %r" % type(POST['payload'])
      auth = str(POST['auth'])
    except:
      response['error'].append('Invalid JSON structure')
    if not self.validAsyncRequest(auth):
      response['error'].append('Invalid auth token')
    if len(response['error']):
      raise JSONCommunicatorAsyncError('%r' % response['error'])
    self.payload, self.response, self.command = POST['payload'], response, command

  def manage_request(self):
    raise ImplementationError('Must be defined by subclass')

  def butWaitTheresMore(self, fields):
    return fields

  def sendRedirect(self, url):
    raise Redirect(url)

  def handleReturnPath(self):
    rp = self.GET.get('return', '').split(':')
    if len(rp) != 2: return
    oid = int(rp[1])
    if oid < 1: return
    try:
      if rp[0] == 'user':
        u = UserProfile.objects.get(id=oid)
        self.returnPath = '/user/%d' % u.id
    except ObjectDoesNotExist, e:
      pass

  def parsePath(self, args, **kwargs):
    for arg in args:
      self.pathArgs[arg] = kwargs.get(arg, None)

  def respond(self):
    self.handleReturnPath()
    try:
      self.manage_request() #Perform any business level logic on the request
    except Redirect, e:
      return HttpResponseRedirect(e.url)
    if self.is_async:
      return HttpResponse(json.dumps(self.response)); #No HTMLizing is necessary, just JSON encode
    elif self.mayReturn and self.returnPath:
      return HttpResponseRedirect(self.returnPath)
    else:
      self.renderPage() #HTMLize
      return HttpResponse(self.response)

  @transaction.autocommit
  def renderPage(self):
    m =messages.get_messages(self.request)
    #assert False, [ _m for _m in m ]
    self.fields['messages'] = m
    self.response = self.renderTemplate()

  @transaction.autocommit
  def renderTemplate(self, template=None, fields=None):
    t = loader.get_template(template or self.template)
    role = user_role_from_user(self.user)
    fields = fields or self.fields
    fields.update({
                    'title' : self._title(),
                    'show_home_link' : True,
                    'user_is_superuser' : self.user.is_superuser,
                    'user' : self.user,
                    'profile' : (not self.user.is_anonymous()) and self.user.get_profile() or None,
                    'form_id' : self.get_form_id(),
                    'role' : role,
                    'jsoncommunicator_key' : self.get_jsoncommunicator_key(),
                  })
    fields = self.butWaitTheresMore(fields)
    c = Context(fields)
    return t.render(c)

  def addMessage(self, level, message):
    assert level in (messages.constants.DEBUG, 
                     messages.constants.INFO, 
                     messages.constants.SUCCESS,
                     messages.constants.WARNING,
                     messages.constants.ERROR
                    )
    messages.add_message(self.request, level, message)

  def expireTokens(self, tokens=None):
    tokens = [ unicode(t)
               for t in tokens or [] \
             ]
    if self.POST.has_key('form_id'):
      tokens.append(unicode(self.POST['form_id']))
    listspace = self.is_async and 'asyncTokens' or 'tokens'
    self.session[listspace] = [
                                t for t in self.session.get(listspace, [])
                                if unicode(t.v) not in tokens
                              ]

  def clearDeadTokens(self):
    listspace = self.is_async and 'asyncTokens' or 'tokens'
    self.session[listspace] = [ t for t in
                               self.session.get(listspace, [])
                               if t()
                             ][-10:]

  def createNewToken(self):
    self.clearDeadTokens()
    listspace = self.is_async and 'asyncTokens' or 'tokens'
    old = self.session.get(listspace, [])
    nt = Token(self)
    while [t for t in old if t(nt.v) ]:
      nt = Token(self) #Ensure it's unique
    self.session[listspace] = old + [nt]
    return nt.v

  def confirmToken(self, auth):
    listspace = self.is_async and 'asyncTokens' or 'tokens'
    #assert False, [ auth ] + [ t.v for t in self.session.get(listspace, []) ]
    return [t for t in self.session.get(listspace, [])
            if t(auth) ] and True or False

  def get_form_id(self):
    return self.createNewToken()

  def get_jsoncommunicator_key(self):
    return self.createNewToken()

  def validAsyncRequest(self, auth):
    return self.confirmToken(auth)

  def validForm(self):
    ##FIXME
    return True
    if self.POST.has_key('form_id') and self.confirmToken(self.POST['form_id']):
      return True
    self.addMessage(messages.contants.ERROR, "Invalid Form Identifier.  Your request was not completed.  Please try again.")
    return False

  def mkCaptcha(self):
    numbers = [ 1,2,4,5,7,8,9 ]
    ints = [ random.choice(numbers) for i in xrange(6) ]
    eq = ("%d" * 6) % tuple(ints)
    answer = sum(ints)
    self.session['captcha'] = answer
    import Image, ImageDraw, ImageFont, os
    bg_path = os.path.join(settings.TEMPLATE_DIRS[0], 'captcha-bg.png')
    im = Image.open(bg_path)
    draw = ImageDraw.Draw(im)
    font_path = 'FreeSansBold.ttf'
    font = ImageFont.truetype(font_path, 64)
    draw.text((15,10), eq, font=font, fill=(80,100,50))
    fname = os.path.join(settings.MEDIA_ROOT, 'img', 'captcha', '%s.png' % self.cookies['sessionid'])
    im.save(fname, 'PNG')
    return mark_safe('<img alt="Captcha" id="captcha" src="/media/img/captcha/%s.png" />' % self.cookies['sessionid'])

  def _captchaValid(self):
    return True
    try:
      if self.method == 'POST':
        if int(self.POST['captcha']) == self.session['captcha']:
          self.session['captcha'] = random.random()
          return True
    except: pass
    self.fields['captcha_error'] = 'Incorrect response.  Please Try Again.'
    return False

  def denyAccessToProtectedPage(self):
    self.addMessage(messages.constants.WARNING, "You don't have permission to do that.")
    self.sendRedirect('/')
