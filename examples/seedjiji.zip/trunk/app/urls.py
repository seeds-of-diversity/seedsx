from django.conf.urls import patterns, include, url

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('seedjiji.views',
    # Examples:
    url(r'^$', 'home', name='home'),
    url(r'^logout', 'logout', name='logout'),
    url(r'^reset/(?P<step>\d+)', 'reset', name='reset_password'),
    url(r'^activate/(?P<user_id>\d+)/(?P<activation_code>[a-z0-9]+)$', 'activate'),
    url(r'^user$', 'account'),
    url(r'^user/(?P<user_id>\d+)?$', 'account'),
    url(r'^user/create$', 'new_account'),
    url(r'^listing/(?P<listing_id>\d+)$', 'listing'),
    url(r'^listing$', 'new_listing'),
    url(r'^listing/my$', 'my_listings'),
    url(r'^search', 'listing_listing'),
    url(r'^feedback/(?P<listing_id>\d+)$', 'feedback'),
    url(r'^fulfill/(?P<listing_id>\d+)$', 'fulfill'),
    url(r'^(?P<object_type>[a-z]+)/upload$', 'upload'),
    url(r'^image/(?P<image_id>\d+)/(?P<width>\d*)/(?P<height>\d*)(/(?P<option>[a-z]*))?$', 'image_serve'),


    # url(r'^seedjiji/', include('seedjiji.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
    url('', 'notfound', name='404')
)
