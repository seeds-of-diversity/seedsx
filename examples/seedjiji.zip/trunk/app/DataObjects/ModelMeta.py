from modelimports import *

class ModelMeta(models.Model):
  objectType = models.CharField(max_length=1, null=False, choices=Configuration.MetaTrackedModels)
  objectId = models.IntegerField()
  ctime = models.DateTimeField(auto_now_add=True)
  mtime = models.DateTimeField(auto_now=True)
  cuser = models.ForeignKey(User, related_name='+')
  muser = models.ForeignKey(User, related_name='+')
