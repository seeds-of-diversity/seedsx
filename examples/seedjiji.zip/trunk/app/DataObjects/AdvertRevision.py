from modelimports import *

class AdvertRevision(models.Model):
  advert = models.ForeignKey('Advert', related_name='revisions')
  species = models.CharField(default='', max_length=256)
  variety = models.CharField(default='', max_length=256)
  quantity = models.PositiveIntegerField(default=0)
  price = models.DecimalField(default=0, decimal_places=2, max_digits=10)
  comments = models.TextField(default='')
  ctime = models.DateTimeField()
