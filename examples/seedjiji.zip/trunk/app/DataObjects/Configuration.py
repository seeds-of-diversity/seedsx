from django.forms import util

class Configuration(object):
  user_roles = ( ( 'u', 'User', ),
                 ( 'A', 'Admin', ),
               )
  ad_types = ( ( 'ba' , 'Buying Active',),
               ( 'bc' , 'Buying Claimed',),
               ( 'bx' , 'Buying Closed',),
               ( 'sa' , 'Selling Active',),
               ( 'sc' , 'Selling Claimed',),
               ( 'sx' , 'Selling Closed',),
                )
  quantity_units = ( ( 'g', 'Gram', ),
                     ( 'kg', 'Kilogram', ),
                     ( 'Mg', 'Tonne (meteric)', ),
                   )
  ad_statii = ( ( 'am', 'Active/Mine', ),
                ( 'cm', 'Closed/Mine', ),
                ( 'aa', 'Active/All', ),
                ( 'ca', 'Closed/All', ),
              )
  distances = ( ( 25, 'Local', ),
                ( 100, '100km', ),
                ( 250, '250km', ),
                ( 400, '400km', ),
                ( 600, '600km', ),
                ( None, 'Any Distance' ),
              )
  provinces = ( ( 'BC', 'British Columbia', ),
                ( 'AB', 'Alberta', ),
                ( 'SK', 'Saskatchewan', ),
                ( 'MB', 'Manitoba', ),
                ( 'ON', 'Ontario', ),
                ( 'QC', 'Quebec', ),
                ( 'NL', 'Newfoundland', ),
                ( 'NS', 'Nova Scotia', ),
                ( 'NB', 'New Brunswick', ),
                ( 'PE', 'P.E.I.', ),
              )
  countries = ( ( 'CA', 'Canada', ), 
                ( 'US', 'United States', ),
                ( 'UK', 'United Kingdom', ),
              )
  max_ad_images = 3
  MetaTrackedModels = ( ('a', 'Advert'),
                        ('b', 'AdvertImage'),
                        ('c', 'AdvertRevision'),
                        ('d', 'Feedback'),
                        ('e', 'UserProfile'),
                      )
  
  @classmethod
  def password_validator(cls, p):
    if len(p) < 6:
      raise util.ValidationError(t('The provided password is too short'))
    def num_part(s):
      n = re.compile(r'\d')
      if n.search(s):
        return True
      return False
    def alpha_part(s):
      a = re.compile(r'[a-zA-Z]')
      if not len(a.findall(p)) >= 3:
        return False
      return True
      
    if not num_part(p):
      raise util.ValidationError(t('The password must contain at least one number'))
    if not alpha_part(p):
      raise util.ValidationError(t('The password must contain at least three letters'))
    return p
