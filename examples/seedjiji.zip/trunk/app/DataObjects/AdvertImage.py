from modelimports import *

class AdvertImage(models.Model):
  fname = models.ImageField(upload_to='incoming/advert_image')
  advert = models.ForeignKey('Advert', related_name="images")
  sequence = models.IntegerField(default=0)
