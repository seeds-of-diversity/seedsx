from modelimports import *

class Advert(models.Model):
  ad_type = models.CharField(max_length=2, default=Configuration.ad_types[0][0], choices=Configuration.ad_types)
  species = models.CharField(default='', max_length=256)
  variety = models.CharField(default='', max_length=256)
  quantity = models.PositiveIntegerField(default=0)
  price = models.DecimalField(default=0, decimal_places=2, max_digits=10)
  comments = models.TextField(default='')
  max_images = Configuration.max_ad_images
  requestor = models.ForeignKey('UserProfile', related_name='Adverts')
