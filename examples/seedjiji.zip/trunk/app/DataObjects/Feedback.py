from modelimports import *

class Feedback(models.Model):
  lister = models.ForeignKey('UserProfile', related_name='l_feedback')
  claimant = models.ForeignKey('UserProfile', related_name='c_feedback')
  owner = models.ForeignKey('UserProfile', related_name='o_feedback')
  parent = models.ForeignKey('Feedback', related_name='responses')
  advert = models.ForeignKey('Advert')
  description = models.TextField(default='', null=False)
  comments = models.TextField(default='', null=False)
  _cache = models.TextField(default=None, null=True)
  positive = models.BooleanField(null=False)
