import urllib, urllib2
import os, time, logging, threading
from pprint import saferepr
try:
  from json import json
except ImportError, e:
  import json

if not hasattr(json, 'write'): json.write = json.dumps
if not hasattr(json, 'read'): json.read = json.loads

class GEORequest(urllib2.Request):
  def __init__(self, *args, **kwargs):
    self._method = kwargs.pop('method', kwargs.get('data') is not None and 'POST' or 'GET')
    urllib2.Request.__init__(self, *args, **kwargs)

  def get_method(self):
    return self._method

from ResponseHandler import ResponseHandler

log = logging.getLogger('HTTPClient')

class GEOHandler(threading.Thread):
  def __init__(self, module, **kwargs):
    self.debug = True
    self.url = module.get_url()
    self.data = module.get_data()
    self.headers = module.headers
    self.responseParser = module.responseParser
    self.responseHandler = ResponseHandler(**kwargs)
    self.urlopener = urllib2.build_opener()
    self.method = self.data is not None and 'POST' or 'GET'
    self.req = GEORequest(self.url, data=self.data, headers=self.headers, method=self.method)
    super(GEOHandler, self).__init__()

  def run(self):
    response = False
    if self.debug:
      self.log('Submitting request to %s with data %s' % (self.url, saferepr(self.data)), level='debug')
    try:
      response = self.urlopener.open(self.req)
    except IOError, e:
      self.log('Error occurred: %s' % saferepr(e), level='error')
    if response:
      if isinstance(response, urllib2.HTTPError):
        self.log('Received HTTP Error in response: %s %s' % (response.code, response.msg), level='warning')
      elif isinstance(response, urllib2.URLError):
        self.log('Received HTTP Error in response: %s' % response.reason, level='warning')
      else:
        self.responseHandler(self.responseParser(response))
    else:
      self.log('No Response from request to %s with data %s' % (self.url, saferepr(self.data)), level='warning')

  def log(self, msg, level):
    print( '%s: %s' % (level, msg))
    log = logging.getLogger('HTTPClient')
    assert level in ( 'error', 'warning', 'info', 'debug'), "Invalid log level %s" % level
    getattr(log, level)(msg)

class GoogleGEOHandler(object):
  def __init__(self, address):
    self.address = urllib2.quote(address)
    self.server = 'maps.googleapis.com'
    self.protocol = 'https'
    self.apiPath = 'maps/api/geocode/json'
    self.params = { 'address' : address,
                    'sensor' : 'false'
                  }
    self.headers = {}


  def get_url(self):
    return '%s://%s/%s?%s' % (self.protocol, self.server, self.apiPath, '&'.join([ '%s=%s' % (urllib2.quote(k), urllib2.quote(v)) for k, v in self.params.items() ]))

  def get_data(self):
    return None

  def responseParser(self, response):
   p = json.read(response.read())
   if len(p['results']) and p['status'] == 'OK':
     g = p['results'][0]['geometry']
     try:
       return { 'latitude' : g['location']['lat'],
                'longitude' : g['location']['lng']
              }
     except KeyError, e:
       assert False, saferepr(g)
   assert False, p
