import sys
from DataObjects.models import UserProfile
from django.db.models import Q
from HTTPClient import GEOHandler, GoogleGEOHandler

try:
  unknown = UserProfile.objects.get(Q(latitude=None)|Q(longitude=None))

  for up in unknown:
    gh = GoogleGEOHandler(address=up.postalCode)
    GH = GEOHandler(gh, userID=up.id, userStore=UserProfile)
    GH.start()
except:
  pass
