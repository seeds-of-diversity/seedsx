class ResponseHandler(object):
  def __init__(self, userID, userStore, latitudeName='latitude', longitudeName='longitude'):
    self.userID = userID
    self.userStore = userStore
    self.latitudeName = latitudeName
    self.longitudeName = longitudeName

  def __call__(self, parsedResponse):
    user = self.userStore.objects.get(id=self.userID)
    setattr(user, self.latitudeName, parsedResponse['latitude'])
    setattr(user, self.longitudeName, parsedResponse['longitude'])
    user.save()

