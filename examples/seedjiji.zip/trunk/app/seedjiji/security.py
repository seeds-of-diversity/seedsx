def user_role_from_user(user):
  return 'U'
