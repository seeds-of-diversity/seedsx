from django import template
from django.utils.safestring import mark_safe
register = template.Library()

@register.filter
def one_col_field(field):
  t = template.loader.get_template('forms/one_col_field.tmpl')
  return t.render(template.Context({ 'field' : field,
                                     'field_class' : 'one-col-field'
                                    }))

@register.filter
def wide_label_field(field):
  t = template.loader.get_template('forms/one_col_field.tmpl')
  return t.render(template.Context({ 'field' : field,
                                     'field_class' : 'wide-label-field',
                                    }))
