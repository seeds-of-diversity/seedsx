from django import template
from django.utils.safestring import mark_safe
register = template.Library()

@register.tag('t')
def do_t(parser, token):
  try:
    tag_name, lang, string = token.split_contents()
  except ValueError, e:
    raise template.TemplateSyntaxError("%r tag requires a single argument" % token.contents.split()[0])
  if not string[0] == string[-1] and string[0] in ( '"', "'" ):
    raise template.TemplateSyntaxError('%r tag second argument must be quoted' % tag_name)
  return template.Node(string[1:-1])

def t(lang, string):
  return string
