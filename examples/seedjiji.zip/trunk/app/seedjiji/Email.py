def new_user(new=None, manager=None, activation_code=None):
  pass

def user_saved(user=None, manager=None):
  pass
