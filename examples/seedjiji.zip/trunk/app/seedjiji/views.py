from Servlets.ViewImports import createView
from Servlets.LogInOut import AuthServlet, Credentials
from Servlets.HomePage import HomePage
from Servlets.Account import AccountServlet
from Servlets.Advert import AdvertServlet
from Servlets.Feedback import FeedbackServlet
from Servlets.FullFill import FullFillServlet
from Servlets.Uploader import Uploader
from Servlets.ImageViews import ImageServlet
from Servlets.Listing import ListingServlet
from Servlets.Error import ErrorServlet

from django.http import HttpResponse
from django.shortcuts import render_to_response

home = createView(HomePage, None)
login = createView(AuthServlet, None, mode='login')
logout = createView(AuthServlet, None, mode='logout')
reset = createView(Credentials, ('step', ), mode='reset')
activate = createView(Credentials, ( 'user_id', 
                                     'activation_code'), mode = 'activate' )
account = createView(AccountServlet, ( 'user_id', ), mode = 'edit' )
new_account = createView(AccountServlet, ( 'user_id', ), mode = 'new' )

listing = createView(AdvertServlet, ( 'listing_id',), mode = 'other' )
new_listing = createView(AdvertServlet, None, mode = 'new' )
my_listings = createView(AdvertServlet, None, mode = 'self' )

feedback = createView(FeedbackServlet, ( 'listing_id',) )

fullfill = createView(FullFillServlet, ( 'listing_id',) )

upload = createView(Uploader, ( 'object_type',) )
image_serve = createView(ImageServlet, ( 'image_id', 'width', 'height', 'option' ))

listing_listing = createView(ListingServlet, None, mode='listing')
feedback_listing = createView(ListingServlet, ('user_id',), mode='feedback')

notfound = createView(ErrorServlet, None, mode='404')

def listing_json():
  pass

def listing_m_json():
  pass

def feedback_json():
  pass

def feedback_m_json():
  pass
