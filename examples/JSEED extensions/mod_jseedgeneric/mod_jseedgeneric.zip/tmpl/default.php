<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

echo $oJMod->Output();
?>
